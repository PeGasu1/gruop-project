from django.apps import AppConfig


class IsiConfig(AppConfig):
    name = 'ISI'
