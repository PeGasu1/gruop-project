from django.test import TestCase
from ISI.models import product

# class ProductModelTests(TestCase):
#
#     def test_product_list(self):
#

